Filelist:
Gerber\XMEGA-E1_XPLAINED_release_rev1.GTL : Gerber file for Top Layer
Gerber\XMEGA-E1_XPLAINED_release_rev1.GTO : Gerber file for Top Overlay (silkscreen)
Gerber\XMEGA-E1_XPLAINED_release_rev1.GTP : Gerber file for Top Paste-mask
Gerber\XMEGA-E1_XPLAINED_release_rev1.GTS : Gerber file for Top Solder-mask
Gerber\XMEGA-E1_XPLAINED_release_rev1.GP1 : Gerber file for Internal Plane 1 (GND)
Gerber\XMEGA-E1_XPLAINED_release_rev1.GP2 : Gerber file for Internal Plane 2 (PWR)
Gerber\XMEGA-E1_XPLAINED_release_rev1.GBL : Gerber file for Bottom Layer
Gerber\XMEGA-E1_XPLAINED_release_rev1.GBO : Gerber file for Bottom Overlay (silkscreen)
Gerber\XMEGA-E1_XPLAINED_release_rev1.GBP : Gerber file for Bottom Paste-mask
Gerber\XMEGA-E1_XPLAINED_release_rev1.GBS : Gerber file for Bottom Solder-mask
Gerber\XMEGA-E1_XPLAINED_release_rev1.GM1 : Gerber file for Mechanical 1 layer (board outline)
XMEGA-E1_XPLAINED_release_rev1.PDF : Schematic, PCB Prints, PCB 3D Prints, Assembly Drawings, BOM 
ExportSTEP\XMEGA-E1_XPLAINED_release_rev1.STEP : 3D model of PCBA
