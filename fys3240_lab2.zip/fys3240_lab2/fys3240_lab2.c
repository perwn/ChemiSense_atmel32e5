/* 
Author       : Bent Furevik
Company      : University of Oslo
File name    : fys3240_lab2.c
Date         : 23.12.2011
Project      : FYS3240 Lab2
Function     : Precode for a microcontrollerprogram interfacing the LCD
*/

#define F_CPU 32000000
#include <avr/io.h>
#include <util/delay.h>
#include "fys3240_lcd.h"



int main()
{
	/* Inits */
	
	while(1){
	/* Test-app */
	}
}
