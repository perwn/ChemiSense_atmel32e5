/* 
Author       : Bent Furevik
Company      : University of Oslo
File name    : fys3240_lab1.h
Date         : 23.12.2011
Project      : FYS3240 Lab1 Solution
Function     : Code for a microcontrollerprogram flashing leds according to pushbuttons 
*/

#define DEVICE ATXMEGA128B1
#define F_CPU 32000000UL
#include "fys3240_led.h"

int main(void)
{
	/* Init here */
	while(1)
	{
		/* Main-loop of your application. 
		 * Your code here. 	*/
	}
}

